import React from "react";

export default function PostNewReports() {
  return <div>PostNewReports</div>;
}
